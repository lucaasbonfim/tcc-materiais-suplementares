package projetoc.mapper;

import projetoc.domain.entity.Cidade;
import projetoc.domain.entity.Modal;
import projetoc.domain.entity.Viagem;
import projetoc.dto.ViagemRequestDTO;
import projetoc.dto.ViagemResponseDTO;
import org.springframework.stereotype.Component;

@Component
public class ViagemMapper {

    public Viagem toEntity(ViagemRequestDTO dto, java.util.Set<Modal> modais, Cidade cidadeOrigem, Cidade cidadeDestino, java.util.Set<Cidade> escalas) {
        if (dto == null) {
            return null;
        }

        Viagem viagem = new Viagem();
        viagem.setModais(modais);
        viagem.setCidadeOrigem(cidadeOrigem);
        viagem.setCidadeDestino(cidadeDestino);
        if (escalas != null) {
            viagem.setEscalas(escalas);
        }
        viagem.setPartida(dto.getPartida());
        viagem.setChegada(dto.getChegada());
        viagem.setPreco(dto.getPreco());

        return viagem;
    }

    public ViagemResponseDTO toResponseDTO(Viagem viagem) {
        if (viagem == null) {
            return null;
        }

        ViagemResponseDTO dto = new ViagemResponseDTO();
        dto.setId(viagem.getId());
        if (viagem.getModais() != null) {
            dto.setIdsModais(viagem.getModais().stream().map(Modal::getId).collect(java.util.stream.Collectors.toList()));
            
            dto.setModais(viagem.getModais().stream().map(m -> {
                ViagemResponseDTO.ModalResponse mr = new ViagemResponseDTO.ModalResponse();
                mr.setTipo(m.getTipo() != null ? m.getTipo().name() : null);
                if (m.getTransportadora() != null) {
                    ViagemResponseDTO.TransportadoraResponse tr = new ViagemResponseDTO.TransportadoraResponse();
                    tr.setNome(m.getTransportadora().getNome());
                    mr.setTransportadora(tr);
                }
                return mr;
            }).collect(java.util.stream.Collectors.toList()));
        }
        if (viagem.getEscalas() != null) {
            dto.setIdsEscalas(viagem.getEscalas().stream().map(Cidade::getId).collect(java.util.stream.Collectors.toList()));
        }
        if (viagem.getCidadeOrigem() != null) {
            dto.setIdCidadeOrigem(viagem.getCidadeOrigem().getId());
            
            ViagemResponseDTO.CidadeResponse co = new ViagemResponseDTO.CidadeResponse();
            co.setNome(viagem.getCidadeOrigem().getNome());
            co.setUf(viagem.getCidadeOrigem().getUf() != null ? viagem.getCidadeOrigem().getUf().name() : null);
            dto.setCidadeOrigem(co);
        }
        if (viagem.getCidadeDestino() != null) {
            dto.setIdCidadeDestino(viagem.getCidadeDestino().getId());
            
            ViagemResponseDTO.CidadeResponse cd = new ViagemResponseDTO.CidadeResponse();
            cd.setNome(viagem.getCidadeDestino().getNome());
            cd.setUf(viagem.getCidadeDestino().getUf() != null ? viagem.getCidadeDestino().getUf().name() : null);
            dto.setCidadeDestino(cd);
        }
        dto.setPartida(viagem.getPartida());
        dto.setChegada(viagem.getChegada());
        dto.setStatus(viagem.getStatus());
        dto.setPreco(viagem.getPreco());

        return dto;
    }
}
