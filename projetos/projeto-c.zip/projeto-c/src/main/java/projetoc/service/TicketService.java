package projetoc.service;

import projetoc.domain.entity.Reserva;
import projetoc.domain.entity.Ticket;
import projetoc.domain.repository.TicketRepository;
import projetoc.dto.TicketResponseDTO;
import projetoc.exception.BusinessException;
import projetoc.exception.ResourceNotFoundException;
import projetoc.mapper.TicketMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.access.AccessDeniedException;
import projetoc.domain.entity.User;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class TicketService {

    private final TicketRepository ticketRepository;
    private final TicketMapper ticketMapper;

    @Transactional
    public Ticket emitirTicket(Reserva reserva) {
        if (ticketRepository.findByReservaId(reserva.getId()).isPresent()) {
            throw new BusinessException("Já existe um ticket emitido para esta reserva.");
        }

        String numero = gerarNumeroTicket();
        String assento = gerarAssento(reserva);
        
        Ticket ticket = reserva.instanciarTicket(numero, assento);
        return ticketRepository.save(ticket);
    }

    @Transactional(readOnly = true)
    public TicketResponseDTO findByNumero(String numero) {
        Ticket ticket = ticketRepository.findByNumero(numero)
                .orElseThrow(() -> new ResourceNotFoundException("Ticket", "numero", numero));

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null) {
            boolean isAdminOrFuncionario = auth.getAuthorities().stream()
                    .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN")
                            || a.getAuthority().equals("ROLE_GERENTE")
                            || a.getAuthority().equals("ROLE_FUNCIONARIO"));

            if (!isAdminOrFuncionario) {
                String currentUsername = auth.getName();
                User donoUser = ticket.getReserva().getCliente().getUser();
                if (donoUser == null || !currentUsername.equals(donoUser.getUsername())) {
                    throw new AccessDeniedException("Acesso negado: O ticket pertence a outro usuário.");
                }
            }
        }

        return ticketMapper.toResponseDTO(ticket);
    }

    @Transactional(readOnly = true)
    public java.util.List<TicketResponseDTO> findAll() {
        return ticketRepository.findAll().stream()
                .map(ticketMapper::toResponseDTO)
                .collect(java.util.stream.Collectors.toList());
    }

    @Transactional(readOnly = true)
    public TicketResponseDTO findByReservaId(Long reservaId) {
        Ticket ticket = ticketRepository.findByReservaId(reservaId)
                .orElseThrow(() -> new ResourceNotFoundException("Ticket não encontrado para esta reserva."));

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null) {
            boolean isAdminOrFuncionario = auth.getAuthorities().stream()
                    .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN")
                            || a.getAuthority().equals("ROLE_GERENTE")
                            || a.getAuthority().equals("ROLE_FUNCIONARIO"));

            if (!isAdminOrFuncionario) {
                String currentUsername = auth.getName();
                User donoUser = ticket.getReserva().getCliente().getUser();
                if (donoUser == null || !currentUsername.equals(donoUser.getUsername())) {
                    throw new AccessDeniedException("Acesso negado: O ticket pertence a outro usuário.");
                }
            }
        }

        return ticketMapper.toResponseDTO(ticket);
    }

    private String gerarNumeroTicket() {
        return "TKT-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }

    private String gerarAssento(Reserva reserva) {
        // Simulação de alocação de assento
        long count = reserva.getId() % 50; // Para gerar assentos de 1 a 50
        char row = (char) ('A' + (count % 10));
        return row + String.valueOf((count / 10) + 1);
    }
}
