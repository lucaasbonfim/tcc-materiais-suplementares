package projetoa.domain.cursoGrade;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import javax.swing.text.html.Option;
import java.util.Optional;

@Repository
public interface CursoGradeRepository extends JpaRepository<CursoGrade, CursoGradeId> {

    Optional<CursoGrade> findById(CursoGradeId id);
}
