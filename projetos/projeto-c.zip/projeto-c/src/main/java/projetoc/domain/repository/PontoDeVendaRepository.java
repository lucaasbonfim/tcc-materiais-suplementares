package projetoc.domain.repository;

import projetoc.domain.entity.PontoDeVenda;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PontoDeVendaRepository extends JpaRepository<PontoDeVenda, Long> {
    Optional<PontoDeVenda> findByCnpj(String cnpj);
}
